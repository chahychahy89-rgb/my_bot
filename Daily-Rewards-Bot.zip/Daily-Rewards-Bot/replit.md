# Telegram Mining Bot

## Overview

A full-stack Telegram mini-app bot with auto-mining, referral system, daily tasks, and leaderboard. Features a dark game-like UI with gold/amber accents.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (artifacts/telegram-bot-app)
- **API framework**: Express 5 (artifacts/api-server)
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **UI**: Tailwind CSS, Framer Motion, Lucide React

## Features

1. **Auto-Mining System**: Users start a mining session (8h), watch ads to boost 2x for 1 hour, and collect coins
2. **Daily Tasks**: Check-in, join channel, share screenshots, invite friends, watch ads — all with coin/diamond rewards
3. **Referral System**: Unique referral links, milestone rewards, friend tracking
4. **Leaderboard**: Top 20 miners ranked by total coins
5. **Profile**: Level progression, stats overview, referral code display

## API Endpoints

- `GET /api/users/:telegramId` — get or create user
- `GET /api/users/:telegramId/balance` — balance & stats
- `GET /api/mining/:telegramId/status` — mining status
- `POST /api/mining/:telegramId/start` — start mining
- `POST /api/mining/:telegramId/boost` — boost after watching ad
- `POST /api/mining/:telegramId/collect` — collect mined coins
- `GET /api/tasks/:telegramId` — get daily tasks
- `POST /api/tasks/:telegramId/:taskId/complete` — complete task & claim reward
- `GET /api/referrals/:telegramId` — referral info
- `POST /api/referrals/:telegramId/register` — register referral
- `GET /api/leaderboard` — top miners

## Key Commands

- `pnpm run typecheck` — full typecheck
- `pnpm run build` — typecheck + build
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks
- `pnpm --filter @workspace/db run push` — push DB schema changes
- `pnpm --filter @workspace/api-server run dev` — run API server
- `pnpm --filter @workspace/telegram-bot-app run dev` — run frontend

## Database Schema

- `users` — user profiles, balances, referral codes
- `mining_sessions` — active mining state per user
- `task_definitions` — available daily tasks
- `user_task_completions` — completed task tracking
- `referrals` — referral relationships and rewards
