import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Pickaxe, CheckSquare, Users, Trophy, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect } from "react";
import { useGetUser } from "@workspace/api-client-react";
import { UserProvider, useTelegramUser } from "./lib/UserContext";

import Home from "./pages/Home";
import Tasks from "./pages/Tasks";
import Referrals from "./pages/Referrals";
import Leaderboard from "./pages/Leaderboard";
import Profile from "./pages/Profile";

const queryClient = new QueryClient();

function BottomNav() {
  const [location, setLocation] = useLocation();

  const tabs = [
    { path: "/", icon: Pickaxe, label: "Mine" },
    { path: "/tasks", icon: CheckSquare, label: "Tasks" },
    { path: "/referrals", icon: Users, label: "Friends" },
    { path: "/leaderboard", icon: Trophy, label: "Rank" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-card/80 backdrop-blur-xl border-t border-card-border z-50 px-2">
      <div className="h-full flex items-center justify-between max-w-md mx-auto">
        {tabs.map((tab) => {
          const isActive = location === tab.path;
          const Icon = tab.icon;

          return (
            <button
              key={tab.path}
              onClick={() => setLocation(tab.path)}
              className="relative flex flex-col items-center justify-center w-16 h-full gap-1"
            >
              {isActive && (
                <motion.div
                  layoutId="bottomNavIndicator"
                  className="absolute top-0 w-8 h-1 bg-primary rounded-b-full"
                  style={{ boxShadow: "0 0 8px hsl(38,92%,50%)" }}
                  initial={false}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
              <Icon
                className={`w-6 h-6 transition-colors duration-200 ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
                style={isActive ? { filter: "drop-shadow(0 0 6px hsl(38,92%,50%))" } : undefined}
              />
              <span className={`text-[10px] font-medium transition-colors duration-200 ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function AppInit() {
  const { telegramId } = useTelegramUser();
  useGetUser(telegramId, {
    query: { staleTime: Infinity }
  });
  return null;
}

function Router() {
  const [location] = useLocation();

  return (
    <div className="min-h-[100dvh] bg-background text-foreground pb-20">
      <AppInit />
      <AnimatePresence mode="wait">
        <Switch location={location} key={location}>
          <Route path="/" component={Home} />
          <Route path="/tasks" component={Tasks} />
          <Route path="/referrals" component={Referrals} />
          <Route path="/leaderboard" component={Leaderboard} />
          <Route path="/profile" component={Profile} />
          <Route>
            <div className="flex items-center justify-center min-h-[100dvh]">
              <h1 className="text-xl font-bold text-muted-foreground">Not Found</h1>
            </div>
          </Route>
        </Switch>
      </AnimatePresence>
      <BottomNav />
    </div>
  );
}

function App() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <UserProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </UserProvider>
    </QueryClientProvider>
  );
}

export default App;
