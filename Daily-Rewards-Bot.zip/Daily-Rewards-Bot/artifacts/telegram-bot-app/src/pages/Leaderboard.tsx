import { motion } from "framer-motion";
import { Trophy, Crown, Medal } from "lucide-react";
import { useGetLeaderboard } from "@workspace/api-client-react";
import { getGetLeaderboardQueryKey } from "@workspace/api-client-react";

export default function Leaderboard() {
  const { data: leaders, isLoading } = useGetLeaderboard({
    query: {
      queryKey: getGetLeaderboardQueryKey(),
      refetchInterval: 30000,
    }
  });

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-300" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="text-sm font-bold text-muted-foreground">#{rank}</span>;
  };

  const getRankBg = (rank: number) => {
    if (rank === 1) return "bg-yellow-500/10 border-yellow-500/30";
    if (rank === 2) return "bg-gray-400/10 border-gray-400/30";
    if (rank === 3) return "bg-amber-600/10 border-amber-600/30";
    return "bg-card border-card-border";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen px-4 py-6"
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Trophy className="w-6 h-6 text-primary" />
        <div>
          <h1 className="text-xl font-bold text-foreground">Top Miners</h1>
          <p className="text-sm text-muted-foreground">Global leaderboard</p>
        </div>
      </div>

      {/* Top 3 podium */}
      {!isLoading && leaders && leaders.length >= 3 && (
        <div className="flex items-end justify-center gap-3 mb-8 px-4">
          {/* 2nd place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-col items-center flex-1"
          >
            <div className="w-14 h-14 bg-gray-400/20 rounded-full flex items-center justify-center mb-2 border-2 border-gray-400/40">
              <span className="text-lg font-black text-gray-300">
                {leaders[1].firstName?.[0]?.toUpperCase()}
              </span>
            </div>
            <p className="text-xs font-semibold text-foreground truncate w-full text-center">{leaders[1].firstName}</p>
            <p className="text-xs text-muted-foreground">{Math.floor(leaders[1].totalCoins).toLocaleString()}</p>
            <div className="w-full h-12 bg-gray-400/20 rounded-t-lg mt-2 flex items-center justify-center">
              <Medal className="w-5 h-5 text-gray-300" />
            </div>
          </motion.div>

          {/* 1st place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0 }}
            className="flex flex-col items-center flex-1"
          >
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mb-2 border-2 border-yellow-500/60"
              style={{ boxShadow: "0 0 20px hsl(38,92%,50%,0.3)" }}
            >
              <span className="text-xl font-black text-yellow-300">
                {leaders[0].firstName?.[0]?.toUpperCase()}
              </span>
            </motion.div>
            <p className="text-xs font-semibold text-foreground truncate w-full text-center">{leaders[0].firstName}</p>
            <p className="text-xs text-primary font-bold">{Math.floor(leaders[0].totalCoins).toLocaleString()}</p>
            <div className="w-full h-16 bg-yellow-500/20 rounded-t-lg mt-2 flex items-center justify-center">
              <Crown className="w-6 h-6 text-yellow-400" />
            </div>
          </motion.div>

          {/* 3rd place */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center flex-1"
          >
            <div className="w-14 h-14 bg-amber-600/20 rounded-full flex items-center justify-center mb-2 border-2 border-amber-600/40">
              <span className="text-lg font-black text-amber-500">
                {leaders[2].firstName?.[0]?.toUpperCase()}
              </span>
            </div>
            <p className="text-xs font-semibold text-foreground truncate w-full text-center">{leaders[2].firstName}</p>
            <p className="text-xs text-muted-foreground">{Math.floor(leaders[2].totalCoins).toLocaleString()}</p>
            <div className="w-full h-8 bg-amber-600/20 rounded-t-lg mt-2 flex items-center justify-center">
              <Medal className="w-4 h-4 text-amber-600" />
            </div>
          </motion.div>
        </div>
      )}

      {/* Full list */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-16 bg-card rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {leaders?.map((entry: any, index: number) => (
            <motion.div
              key={entry.rank}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.03 }}
              className={`flex items-center gap-3 p-3 rounded-xl border ${getRankBg(entry.rank)}`}
            >
              <div className="w-8 flex items-center justify-center flex-shrink-0">
                {getRankIcon(entry.rank)}
              </div>
              <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-sm font-bold text-muted-foreground">
                  {entry.firstName?.[0]?.toUpperCase() ?? "?"}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{entry.firstName}</p>
                <p className="text-xs text-muted-foreground">@{entry.username} • Lv.{entry.level}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-sm font-bold text-primary">{Math.floor(entry.totalCoins).toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">coins</p>
              </div>
            </motion.div>
          ))}

          {(!leaders || leaders.length === 0) && (
            <div className="text-center py-12">
              <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">No miners yet. Start mining to appear here!</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
