import { motion } from "framer-motion";
import { CheckCircle2, Calendar, Send, Share2, UserPlus, Play, Star, ExternalLink } from "lucide-react";
import { useGetDailyTasks, useCompleteTask, useGetUserBalance } from "@workspace/api-client-react";
import { getGetDailyTasksQueryKey, getGetUserBalanceQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useTelegramUser } from "../lib/UserContext";

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Calendar,
  Send,
  Share2,
  UserPlus,
  Play,
  Star,
};

export default function Tasks() {
  const queryClient = useQueryClient();
  const { telegramId } = useTelegramUser();
  const [celebrating, setCelebrating] = useState<string | null>(null);

  const { data: tasks, isLoading } = useGetDailyTasks(telegramId, {
    query: { queryKey: getGetDailyTasksQueryKey(telegramId) }
  });

  const { data: balance } = useGetUserBalance(telegramId, {
    query: { queryKey: getGetUserBalanceQueryKey(telegramId) }
  });

  const completeTask = useCompleteTask();

  const handleComplete = (taskId: string) => {
    completeTask.mutate(
      { telegramId, taskId },
      {
        onSuccess: (data) => {
          if ((data as any)?.success) {
            setCelebrating(taskId);
            setTimeout(() => setCelebrating(null), 1500);
            queryClient.invalidateQueries({ queryKey: getGetDailyTasksQueryKey(telegramId) });
            queryClient.invalidateQueries({ queryKey: getGetUserBalanceQueryKey(telegramId) });
          }
        }
      }
    );
  };

  const completedCount = tasks?.filter((t: any) => t.isCompleted).length ?? 0;
  const totalCount = tasks?.length ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen px-4 py-6"
    >
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-bold text-foreground">Daily Quests</h1>
        <p className="text-sm text-muted-foreground">Complete tasks to earn rewards</p>
      </div>

      {/* Progress summary */}
      <div className="bg-card border border-card-border rounded-2xl p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-foreground">Today's Progress</span>
          <span className="text-sm font-bold text-primary">{completedCount}/{totalCount}</span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary rounded-full"
            style={{ boxShadow: "0 0 8px hsl(38,92%,50%)" }}
            initial={{ width: 0 }}
            animate={{ width: totalCount ? `${(completedCount / totalCount) * 100}%` : "0%" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          />
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs text-muted-foreground">Coins: {Math.floor(balance?.totalCoins ?? 0).toLocaleString()}</span>
          <span className="text-xs text-muted-foreground">Diamonds: {(balance?.diamonds ?? 0).toFixed(1)}</span>
        </div>
      </div>

      {/* Task list */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-20 bg-card rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {tasks?.map((task: any, index: number) => {
            const Icon = ICON_MAP[task.icon] ?? Star;
            const isCelebrating = celebrating === task.id;

            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`bg-card border rounded-2xl p-4 ${
                  task.isCompleted ? "border-primary/30 bg-primary/5" : "border-card-border"
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Icon */}
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    task.isCompleted
                      ? "bg-primary/20"
                      : task.rewardType === "diamonds"
                      ? "bg-[hsl(195,100%,10%)]"
                      : "bg-muted"
                  }`}>
                    {isCelebrating ? (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.3, 1] }}
                        transition={{ duration: 0.4 }}
                      >
                        <CheckCircle2 className="w-6 h-6 text-primary" />
                      </motion.div>
                    ) : (
                      <Icon className={`w-5 h-5 ${
                        task.isCompleted ? "text-primary" :
                        task.rewardType === "diamonds" ? "text-[hsl(195,100%,50%)]" : "text-muted-foreground"
                      }`} />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-semibold ${task.isCompleted ? "text-muted-foreground line-through" : "text-foreground"}`}>
                        {task.title}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{task.description}</p>
                  </div>

                  {/* Reward + action */}
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <span className={`text-xs font-bold ${task.rewardType === "diamonds" ? "text-[hsl(195,100%,50%)]" : "text-primary"}`}>
                      +{task.reward} {task.rewardType === "diamonds" ? "diamonds" : "coins"}
                    </span>

                    {task.isCompleted ? (
                      <div className="flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                        <span className="text-xs text-primary">Done</span>
                      </div>
                    ) : (
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          if (task.link) window.open(task.link, "_blank");
                          handleComplete(task.id);
                        }}
                        disabled={completeTask.isPending}
                        className="flex items-center gap-1 bg-primary/20 hover:bg-primary/30 text-primary text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors"
                      >
                        {task.link && <ExternalLink className="w-3 h-3" />}
                        Claim
                      </motion.button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Reset note */}
      <p className="text-xs text-muted-foreground text-center mt-6">
        Daily tasks reset at midnight. Come back tomorrow!
      </p>
    </motion.div>
  );
}
