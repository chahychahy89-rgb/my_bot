import { motion } from "framer-motion";
import { Users, Copy, Check, Gift, UserPlus, Share2, Trophy, Crown, Medal } from "lucide-react";
import { useGetReferrals, useGetReferralLeaderboard } from "@workspace/api-client-react";
import { getGetReferralsQueryKey, getGetReferralLeaderboardQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { useTelegramUser } from "../lib/UserContext";

declare const window: Window & {
  Telegram?: { WebApp?: { openTelegramLink?: (url: string) => void } };
};

export default function Referrals() {
  const { telegramId } = useTelegramUser();
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"invite" | "leaderboard">("invite");

  const { data: referralData, isLoading } = useGetReferrals(telegramId, {
    query: { queryKey: getGetReferralsQueryKey(telegramId) }
  });

  const { data: leaderboard, isLoading: leaderLoading } = useGetReferralLeaderboard({
    query: {
      queryKey: getGetReferralLeaderboardQueryKey(),
      refetchInterval: 30000,
    }
  });

  const handleCopy = () => {
    if (referralData?.referralLink) {
      navigator.clipboard.writeText(referralData.referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = () => {
    const msg = referralData?.shareMessage ?? "";
    const link = referralData?.referralLink ?? "";
    const tg = window.Telegram?.WebApp;
    if (tg?.openTelegramLink) {
      const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(msg)}`;
      tg.openTelegramLink(url);
    } else {
      const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(msg)}`;
      window.open(url, "_blank");
    }
  };

  const totalReferrals = referralData?.totalReferrals ?? 0;
  const referralEarnings = referralData?.referralEarnings ?? 0;
  const friends = referralData?.friends ?? [];
  const milestones = referralData?.milestones ?? [];
  const inviterReward = referralData?.inviterReward ?? 1000;
  const welcomeReward = referralData?.welcomeReward ?? 500;

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-4 h-4 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-4 h-4 text-gray-300" />;
    if (rank === 3) return <Medal className="w-4 h-4 text-amber-600" />;
    return <span className="text-xs font-bold text-muted-foreground">#{rank}</span>;
  };

  const getRankBg = (rank: number) => {
    if (rank === 1) return "bg-yellow-500/10 border-yellow-500/30";
    if (rank === 2) return "bg-gray-400/10 border-gray-400/30";
    if (rank === 3) return "bg-amber-600/10 border-amber-600/30";
    return "bg-card border-card-border";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen px-4 py-6 pb-24"
    >
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-xl font-bold text-foreground">Referral System</h1>
        <p className="text-sm text-muted-foreground">Invite friends & earn together</p>
      </div>

      {/* Rewards banner */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        <div className="bg-primary/10 border border-primary/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-black text-primary">+{inviterReward.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground mt-0.5">coins for you</p>
          <p className="text-[10px] text-primary/70 mt-1">per friend invited</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-black text-green-400">+{welcomeReward.toLocaleString()}</p>
          <p className="text-xs text-muted-foreground mt-0.5">welcome gift</p>
          <p className="text-[10px] text-green-400/70 mt-1">for your friend</p>
        </div>
      </div>

      {/* Stats card */}
      <div className="relative bg-card border border-card-border rounded-2xl p-5 mb-5 overflow-hidden">
        <div className="absolute top-0 right-0 w-28 h-28 rounded-full bg-primary/10 -translate-y-6 translate-x-6" />
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-black text-foreground">{totalReferrals}</p>
              <p className="text-xs text-muted-foreground">friends invited</p>
            </div>
            <div className="ml-auto text-right">
              <p className="text-lg font-bold text-primary">{Math.floor(referralEarnings).toLocaleString()}</p>
              <p className="text-xs text-muted-foreground">coins earned</p>
            </div>
          </div>

          {/* Referral link */}
          <div className="bg-muted rounded-xl p-3 flex items-center gap-2 mb-3">
            <span className="text-xs text-muted-foreground flex-1 truncate font-mono">
              {referralData?.referralLink ?? "Loading..."}
            </span>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleCopy}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex-shrink-0 ${
                copied ? "bg-green-500/20 text-green-400" : "bg-primary/20 text-primary"
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Copy"}
            </motion.button>
          </div>

          {/* Share button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={handleShare}
            className="w-full flex items-center justify-center gap-2 py-3 bg-primary text-primary-foreground rounded-xl font-bold text-sm"
          >
            <Share2 className="w-4 h-4" />
            Invite Friends & Earn {inviterReward.toLocaleString()} Coins
          </motion.button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-card border border-card-border rounded-xl p-1 mb-5 gap-1">
        {(["invite", "leaderboard"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors capitalize ${
              activeTab === tab
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground"
            }`}
          >
            {tab === "invite" ? "My Friends" : "🏆 Top Inviters"}
          </button>
        ))}
      </div>

      {/* Tab: My Friends */}
      {activeTab === "invite" && (
        <>
          {/* Milestones */}
          <div className="mb-5">
            <h2 className="text-sm font-semibold text-foreground mb-3">Milestones</h2>
            <div className="space-y-2">
              {milestones.map((milestone: any, index: number) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`flex items-center gap-3 p-3 rounded-xl border ${
                    milestone.isAchieved
                      ? "bg-primary/10 border-primary/30"
                      : "bg-card border-card-border"
                  }`}
                >
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    milestone.isAchieved ? "bg-primary/20" : "bg-muted"
                  }`}>
                    <Gift className={`w-4 h-4 ${milestone.isAchieved ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-semibold ${milestone.isAchieved ? "text-foreground" : "text-muted-foreground"}`}>
                      {milestone.label}
                    </p>
                    <p className="text-xs text-muted-foreground">Invite {milestone.count} friends</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className={`text-sm font-bold ${milestone.rewardType === "diamonds" ? "text-[hsl(195,100%,50%)]" : "text-primary"}`}>
                      +{milestone.reward} {milestone.rewardType}
                    </p>
                    {milestone.isAchieved && <span className="text-xs text-green-400">Achieved ✓</span>}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Friends list */}
          {friends.length > 0 ? (
            <div>
              <h2 className="text-sm font-semibold text-foreground mb-3">Your Friends ({friends.length})</h2>
              <div className="space-y-2">
                {friends.map((friend: any, index: number) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center gap-3 bg-card border border-card-border rounded-xl p-3"
                  >
                    <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-muted-foreground">
                        {friend.firstName?.[0]?.toUpperCase() ?? "?"}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-foreground">{friend.firstName}</p>
                      <p className="text-xs text-muted-foreground">@{friend.username}</p>
                    </div>
                    <span className="text-xs font-bold text-primary">+{friend.reward} coins</span>
                  </motion.div>
                ))}
              </div>
            </div>
          ) : (
            !isLoading && (
              <div className="flex flex-col items-center py-10 text-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
                  <UserPlus className="w-8 h-8 text-muted-foreground" />
                </div>
                <p className="text-sm font-semibold text-foreground mb-1">No friends yet</p>
                <p className="text-xs text-muted-foreground">Share your link to start earning referral rewards</p>
              </div>
            )
          )}
        </>
      )}

      {/* Tab: Top Inviters leaderboard */}
      {activeTab === "leaderboard" && (
        <div>
          <h2 className="text-sm font-semibold text-foreground mb-3">Top 10 Inviters</h2>
          {leaderLoading ? (
            <div className="space-y-2">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="h-14 bg-card rounded-xl animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {(leaderboard ?? []).map((entry: any, index: number) => (
                <motion.div
                  key={entry.telegramId}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.04 }}
                  className={`flex items-center gap-3 p-3 rounded-xl border ${getRankBg(entry.rank)}`}
                >
                  <div className="w-7 flex items-center justify-center flex-shrink-0">
                    {getRankIcon(entry.rank)}
                  </div>
                  <div className="w-9 h-9 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-sm font-bold text-muted-foreground">
                      {entry.firstName?.[0]?.toUpperCase() ?? "?"}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground truncate">{entry.firstName}</p>
                    <p className="text-xs text-muted-foreground">@{entry.username} · Lv.{entry.level}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-primary">{entry.referralCount} friends</p>
                    <p className="text-xs text-muted-foreground">{Math.floor(entry.referralEarnings).toLocaleString()} coins</p>
                  </div>
                </motion.div>
              ))}
              {(!leaderboard || leaderboard.length === 0) && (
                <div className="text-center py-12">
                  <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">No inviters yet. Be the first!</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
