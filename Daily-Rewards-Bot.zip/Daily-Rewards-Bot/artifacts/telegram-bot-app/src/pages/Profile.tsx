import { motion } from "framer-motion";
import { User, Star, Pickaxe, Users, CheckSquare, TrendingUp } from "lucide-react";
import { useGetUser, useGetUserBalance } from "@workspace/api-client-react";
import { getGetUserQueryKey, getGetUserBalanceQueryKey } from "@workspace/api-client-react";
import { useTelegramUser } from "../lib/UserContext";

const LEVEL_NAMES: Record<number, string> = {
  1: "Rookie Miner",
  2: "Stone Breaker",
  3: "Iron Miner",
  4: "Gold Digger",
  5: "Diamond Seeker",
  6: "Crystal Master",
  7: "Gem Lord",
  8: "Vault Guardian",
  9: "Mining Legend",
  10: "Crypto King",
};

export default function Profile() {
  const { telegramId, firstName: tgFirstName, username: tgUsername } = useTelegramUser();

  const { data: user } = useGetUser(telegramId, {
    query: { queryKey: getGetUserQueryKey(telegramId) }
  });

  const { data: balance } = useGetUserBalance(telegramId, {
    query: { queryKey: getGetUserBalanceQueryKey(telegramId) }
  });

  const level = balance?.level ?? 1;
  const totalCoins = balance?.totalCoins ?? 0;
  const nextLevelCoins = balance?.nextLevelCoins ?? 1000;
  const diamonds = balance?.diamonds ?? 0;
  const referralCount = balance?.referralCount ?? 0;
  const tasksCompleted = balance?.tasksCompleted ?? 0;
  const levelProgress = Math.min((totalCoins / nextLevelCoins) * 100, 100);
  const levelName = LEVEL_NAMES[level] ?? "Unknown";

  const stats = [
    { icon: Pickaxe, label: "Total Coins", value: Math.floor(totalCoins).toLocaleString(), color: "text-primary" },
    { icon: Star, label: "Diamonds", value: diamonds.toFixed(1), color: "text-[hsl(195,100%,50%)]" },
    { icon: Users, label: "Friends Invited", value: referralCount.toString(), color: "text-purple-400" },
    { icon: CheckSquare, label: "Tasks Done", value: tasksCompleted.toString(), color: "text-green-400" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen px-4 py-6"
    >
      {/* Profile header */}
      <div className="flex flex-col items-center mb-8">
        <motion.div
          className="relative w-24 h-24 mb-4"
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          <div
            className="w-full h-full rounded-full bg-gradient-to-br from-primary/40 to-purple-500/40 flex items-center justify-center border-2 border-primary/50"
            style={{ boxShadow: "0 0 30px hsl(38,92%,50%,0.3)" }}
          >
            <User className="w-12 h-12 text-primary" />
          </div>

          {/* Level badge */}
          <div className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground text-xs font-black w-8 h-8 rounded-full flex items-center justify-center border-2 border-background">
            {level}
          </div>
        </motion.div>

        <h2 className="text-xl font-bold text-foreground">{user?.firstName ?? tgFirstName}</h2>
        <p className="text-sm text-muted-foreground">@{user?.username ?? tgUsername}</p>

        {/* Level badge */}
        <div className="flex items-center gap-2 mt-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-primary" />
          <span className="text-sm font-semibold text-primary">{levelName}</span>
        </div>
      </div>

      {/* Level progress */}
      <div className="bg-card border border-card-border rounded-2xl p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-semibold text-foreground">Level Progress</span>
          <span className="text-sm font-bold text-primary">Lv.{level} → Lv.{level + 1}</span>
        </div>
        <div className="h-3 bg-muted rounded-full overflow-hidden mb-2">
          <motion.div
            className="h-full bg-primary rounded-full"
            style={{ boxShadow: "0 0 8px hsl(38,92%,50%)" }}
            initial={{ width: 0 }}
            animate={{ width: `${levelProgress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{Math.floor(totalCoins).toLocaleString()} coins</span>
          <span>{Math.floor(nextLevelCoins).toLocaleString()} coins needed</span>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="bg-card border border-card-border rounded-2xl p-4"
            >
              <Icon className={`w-5 h-5 mb-2 ${stat.color}`} />
              <p className={`text-lg font-black ${stat.color}`}>{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Referral code */}
      <div className="bg-card border border-card-border rounded-2xl p-4">
        <h3 className="text-sm font-semibold text-foreground mb-2">Your Referral Code</h3>
        <div className="bg-muted rounded-xl p-3 text-center">
          <span className="text-lg font-black text-primary tracking-widest">
            {user?.referralCode ?? "Loading..."}
          </span>
        </div>
        <p className="text-xs text-muted-foreground text-center mt-2">
          Share this code with friends to earn rewards
        </p>
      </div>
    </motion.div>
  );
}
