import { motion, AnimatePresence } from "framer-motion";
import { Pickaxe, Zap, ChevronDown, Gift, UserPlus } from "lucide-react";
import { useLocation } from "wouter";
import {
  useGetMiningStatus, useStartMining, useBoostMining,
  useCollectMining, useGetUserBalance,
  getGetMiningStatusQueryKey, getGetUserBalanceQueryKey,
} from "@workspace/api-client-react";
import { useState, useCallback, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useTelegramUser } from "../lib/UserContext";
import { useAdsgram } from "../lib/useAdsgram";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const DAILY_AD_LIMIT = 20;

export default function Home() {
  const queryClient = useQueryClient();
  const { telegramId } = useTelegramUser();
  const [, setLocation] = useLocation();

  const [toast, setToast] = useState<{ msg: string; type: "gold" | "blue" | "green" } | null>(null);
  const [adLoading, setAdLoading] = useState(false);
  const [dailyAdCount, setDailyAdCount] = useState(0);
  const [adLimitReached, setAdLimitReached] = useState(false);

  // Fetch daily ad status on mount
  useEffect(() => {
    fetch(`${API_BASE}/api/users/${telegramId}/ad-status`)
      .then((r) => r.json())
      .then((data) => {
        setDailyAdCount(data.dailyAdCount ?? 0);
        setAdLimitReached(data.limitReached ?? false);
      })
      .catch(() => {});
  }, [telegramId]);

  const { data: miningStatus } = useGetMiningStatus(telegramId, {
    query: { refetchInterval: 3000, queryKey: getGetMiningStatusQueryKey(telegramId) },
  });
  const { data: balance } = useGetUserBalance(telegramId, {
    query: { refetchInterval: 5000, queryKey: getGetUserBalanceQueryKey(telegramId) },
  });

  const startMining = useStartMining();
  const boostMining = useBoostMining();
  const collectMining = useCollectMining();

  const showToast = (msg: string, type: "gold" | "blue" | "green" = "gold") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleStart = () => {
    startMining.mutate({ telegramId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMiningStatusQueryKey(telegramId) });
        showToast("⛏ Mining started!", "gold");
      },
    });
  };

  const handleCollect = () => {
    collectMining.mutate({ telegramId }, {
      onSuccess: (data) => {
        const coins = Math.floor((data as any)?.collectedCoins ?? 0);
        queryClient.invalidateQueries({ queryKey: getGetMiningStatusQueryKey(telegramId) });
        queryClient.invalidateQueries({ queryKey: getGetUserBalanceQueryKey(telegramId) });
        showToast(`+${coins.toLocaleString()} coins collected!`, "gold");
      },
    });
  };

  // Called after Adsgram ad finishes → reward 500 coins + 2x boost
  const onAdReward = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/users/${telegramId}/ad-reward`, { method: "POST" });
      const data = await res.json();

      if (data.limitReached && !data.success) {
        setAdLimitReached(true);
        setDailyAdCount(DAILY_AD_LIMIT);
        showToast("لقد استنفدت محاولاتك اليوم!", "blue");
        return;
      }

      if (!data.success) throw new Error("Reward failed");

      // Update daily counter
      setDailyAdCount(data.dailyAdCount ?? 0);
      setAdLimitReached(data.limitReached ?? false);

      // Also activate 2x mining boost if mining is active
      if (miningStatus?.isActive && !miningStatus?.isBoosted) {
        boostMining.mutate({ telegramId }, {
          onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetMiningStatusQueryKey(telegramId) }),
        });
      }

      queryClient.invalidateQueries({ queryKey: getGetUserBalanceQueryKey(telegramId) });
      showToast(`🎉 +500 عملة! تمت المشاهدة (${data.dailyAdCount}/${DAILY_AD_LIMIT})`, "green");
    } catch {
      showToast("حدث خطأ. حاول مجدداً.", "gold");
    }
  }, [telegramId, miningStatus]);

  const { showAd } = useAdsgram({
    onReward: onAdReward,
    onError: (err) => showToast(err, "gold"),
    onSkip: () => showToast("شاهد الإعلان كاملاً لتكسب العملات!", "blue"),
  });

  const handleBoostLuck = () => {
    if (adLimitReached) return;
    setAdLoading(true);
    showAd().finally(() => setAdLoading(false));
  };

  const isActive = miningStatus?.isActive ?? false;
  const isBoosted = miningStatus?.isBoosted ?? false;
  const progress = miningStatus?.progressPercent ?? 0;
  const pendingCoins = miningStatus?.pendingCoins ?? 0;
  const coinsPerHour = miningStatus?.coinsPerHour ?? 100;
  const hoursRemaining = miningStatus?.hoursRemaining ?? 8;
  const totalCoins = balance?.totalCoins ?? 0;
  const diamonds = balance?.diamonds ?? 0;

  const toastColor = {
    gold: "bg-primary text-primary-foreground",
    blue: "bg-[hsl(195,100%,50%)] text-black",
    green: "bg-green-500 text-white",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="min-h-screen px-4 py-6"
    >
      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            key="toast"
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.9 }}
            className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-2xl font-bold text-sm shadow-lg ${toastColor[toast.type]}`}
          >
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-foreground">Mining Hub</h1>
          <p className="text-sm text-muted-foreground">{isActive ? "Auto-mining active" : "Start to earn coins"}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <span className="text-xs text-muted-foreground">Diamonds</span>
            <span className="text-sm font-bold text-[hsl(195,100%,50%)]">{diamonds.toFixed(1)}</span>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex flex-col items-end">
            <span className="text-xs text-muted-foreground">Coins</span>
            <span className="text-sm font-bold text-primary">{Math.floor(totalCoins).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Mining Core */}
      <div className="flex flex-col items-center mb-6">
        <div className="relative w-48 h-48 flex items-center justify-center mb-6">
          {/* Glow */}
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{
              background: isActive
                ? isBoosted
                  ? "conic-gradient(from 0deg, hsl(195,100%,50%), hsl(38,92%,50%), hsl(280,60%,50%), hsl(195,100%,50%))"
                  : "conic-gradient(from 0deg, hsl(38,92%,50%), hsl(38,60%,30%), hsl(38,92%,50%))"
                : "conic-gradient(from 0deg, hsl(232,40%,20%), hsl(232,40%,15%), hsl(232,40%,20%))",
              opacity: 0.3,
              filter: "blur(12px)",
            }}
            animate={isActive ? { rotate: 360 } : { rotate: 0 }}
            transition={{ duration: 4, repeat: isActive ? Infinity : 0, ease: "linear" }}
          />
          {/* SVG ring */}
          <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="85" fill="none" stroke="hsl(232,40%,20%)" strokeWidth="8" />
            <motion.circle
              cx="100" cy="100" r="85"
              fill="none"
              stroke={isBoosted ? "hsl(195,100%,50%)" : "hsl(38,92%,50%)"}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 85}`}
              strokeDashoffset={`${2 * Math.PI * 85 * (1 - progress / 100)}`}
              style={{ filter: `drop-shadow(0 0 6px ${isBoosted ? "hsl(195,100%,50%)" : "hsl(38,92%,50%)"})` }}
              transition={{ duration: 0.5 }}
            />
          </svg>
          {/* Center */}
          <motion.div
            className="relative z-10 flex flex-col items-center"
            animate={isActive ? { scale: [1, 1.05, 1] } : { scale: 1 }}
            transition={{ duration: 2, repeat: isActive ? Infinity : 0 }}
          >
            <Pickaxe
              className={`w-12 h-12 mb-1 ${isActive ? (isBoosted ? "text-[hsl(195,100%,50%)]" : "text-primary") : "text-muted-foreground"}`}
              style={{ filter: isActive ? "drop-shadow(0 0 8px currentColor)" : "none" }}
            />
            <span className="text-2xl font-black text-foreground">
              {Math.floor(pendingCoins).toLocaleString()}
            </span>
            <span className="text-xs text-muted-foreground">pending coins</span>
          </motion.div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 w-full mb-4">
          <div className="bg-card rounded-xl p-3 border border-card-border text-center">
            <span className="text-xs text-muted-foreground block">Per Hour</span>
            <span className="text-base font-bold text-primary">{coinsPerHour}</span>
          </div>
          <div className="bg-card rounded-xl p-3 border border-card-border text-center">
            <span className="text-xs text-muted-foreground block">Progress</span>
            <span className="text-base font-bold text-foreground">{progress.toFixed(0)}%</span>
          </div>
          <div className="bg-card rounded-xl p-3 border border-card-border text-center">
            <span className="text-xs text-muted-foreground block">Remaining</span>
            <span className="text-base font-bold text-foreground">{hoursRemaining.toFixed(1)}h</span>
          </div>
        </div>

        {/* Boost badge */}
        <AnimatePresence>
          {isBoosted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-2 bg-[hsl(195,100%,10%)] border border-[hsl(195,100%,30%)] rounded-full px-4 py-2 mb-4"
            >
              <Zap className="w-4 h-4 text-[hsl(195,100%,50%)]" />
              <span className="text-sm font-semibold text-[hsl(195,100%,50%)]">200% Speed Active</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mining action buttons */}
        <div className="flex gap-3 w-full mb-3">
          {!isActive ? (
            <motion.button
              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              onClick={handleStart}
              disabled={startMining.isPending}
              className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-4 rounded-2xl text-base"
              style={{ boxShadow: "0 0 20px hsl(38,92%,50%, 0.4)" }}
            >
              <Pickaxe className="w-5 h-5" />
              Start Mining
            </motion.button>
          ) : (
            <motion.button
              whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              onClick={handleCollect}
              disabled={collectMining.isPending || pendingCoins === 0}
              className="flex-1 flex items-center justify-center gap-2 bg-primary text-primary-foreground font-bold py-4 rounded-2xl text-base disabled:opacity-50"
              style={{ boxShadow: "0 0 20px hsl(38,92%,50%, 0.4)" }}
            >
              <ChevronDown className="w-5 h-5" />
              Collect {pendingCoins > 0 ? `${Math.floor(pendingCoins).toLocaleString()}` : ""}
            </motion.button>
          )}
        </div>

        {/* ✨ Boost Luck (Watch Ad) button — always visible */}
        {adLimitReached ? (
          /* Limit reached state */
          <div className="w-full rounded-2xl p-4 text-center border border-muted bg-muted/20">
            <p className="text-sm font-bold text-muted-foreground mb-1">
              لقد استنفدت محاولاتك اليوم، عد غداً للمزيد من الأرباح! 🌙
            </p>
            <p className="text-xs text-muted-foreground">
              {DAILY_AD_LIMIT}/{DAILY_AD_LIMIT} إعلانات اليوم
            </p>
          </div>
        ) : (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleBoostLuck}
            disabled={adLoading}
            className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl font-bold text-base relative overflow-hidden disabled:opacity-70"
            style={{
              background: "linear-gradient(135deg, hsl(280,80%,20%), hsl(195,100%,15%))",
              border: "1px solid hsl(280,60%,45%)",
              boxShadow: "0 0 20px hsl(280,60%,30%)",
            }}
            animate={!adLoading ? {
              boxShadow: [
                "0 0 12px hsl(280,60%,25%)",
                "0 0 24px hsl(280,60%,45%)",
                "0 0 12px hsl(280,60%,25%)",
              ],
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {/* Shine sweep */}
            {!adLoading && (
              <motion.div
                className="absolute inset-0 opacity-20"
                style={{ background: "linear-gradient(90deg, transparent, white, transparent)", transform: "skewX(-20deg)" }}
                animate={{ x: ["-150%", "200%"] }}
                transition={{ duration: 2.5, repeat: Infinity, repeatDelay: 1 }}
              />
            )}

            {adLoading ? (
              <>
                <motion.div
                  className="w-5 h-5 rounded-full border-2 border-white/30 border-t-white"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                />
                <span className="text-white">جارٍ تحميل الإعلان...</span>
              </>
            ) : (
              <>
                <Gift className="w-5 h-5 text-purple-300 flex-shrink-0" />
                <span className="text-white">مشاهدة الإعلانات</span>
                <div className="flex items-center gap-1.5 ml-auto flex-shrink-0">
                  <span className="text-xs font-bold text-green-300 bg-green-900/50 px-2 py-0.5 rounded-full">+500</span>
                  <span className="text-xs text-purple-300 bg-purple-900/50 px-2 py-0.5 rounded-full font-mono">
                    {dailyAdCount}/{DAILY_AD_LIMIT}
                  </span>
                </div>
              </>
            )}
          </motion.button>
        )}
      </div>

      {/* Invite Friends button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.97 }}
        onClick={() => setLocation("/referrals")}
        className="w-full flex items-center justify-between px-5 py-4 rounded-2xl font-bold text-sm"
        style={{
          background: "linear-gradient(135deg, hsl(140,60%,12%), hsl(140,60%,18%))",
          border: "1px solid hsl(140,60%,35%)",
          boxShadow: "0 0 16px hsl(140,60%,20%)",
        }}
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-green-500/20 rounded-xl flex items-center justify-center">
            <UserPlus className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-left">
            <p className="text-sm font-bold text-green-300">Invite Friends</p>
            <p className="text-xs text-green-500/80">You get +1000 · Friend gets +500</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-green-300 bg-green-900/50 px-2 py-0.5 rounded-full">+1000</span>
          <span className="text-green-400 text-lg">→</span>
        </div>
      </motion.button>

      {/* Info card */}
      <div className="bg-card border border-card-border rounded-2xl p-4">
        <h3 className="text-sm font-semibold text-foreground mb-2">How Mining Works</h3>
        <ul className="space-y-1">
          <li className="text-xs text-muted-foreground flex items-center gap-2">
            <span className="text-primary">⛏</span> Mining runs automatically for up to 8 hours
          </li>
          <li className="text-xs text-muted-foreground flex items-center gap-2">
            <span className="text-purple-400">🎁</span> Watch an ad to earn +500 coins instantly
          </li>
          <li className="text-xs text-muted-foreground flex items-center gap-2">
            <span className="text-[hsl(195,100%,50%)]">⚡</span> Ad also boosts mining speed to 200% for 1 hour
          </li>
          <li className="text-xs text-muted-foreground flex items-center gap-2">
            <span className="text-green-400">👥</span> Invite friends to earn +1000 coins, they get +500 welcome gift
          </li>
        </ul>
      </div>
    </motion.div>
  );
}
