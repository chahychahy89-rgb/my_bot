import { useCallback, useEffect, useRef } from "react";

// Adsgram Block ID
const TEST_BLOCK_ID = "27857";

declare global {
  interface Window {
    Adsgram?: {
      init: (params: {
        blockId: string;
        debug?: boolean;
        debugBannerType?: string;
      }) => AdController;
    };
  }
}

interface AdController {
  show: () => Promise<AdResult>;
  destroy: () => void;
}

interface AdResult {
  done: boolean;
  description: string;
  state: string;
  error: boolean;
}

interface UseAdsgramOptions {
  blockId?: string;
  onReward: () => void | Promise<void>;
  onError?: (err: string) => void;
  onSkip?: () => void;
}

export function useAdsgram({ blockId = TEST_BLOCK_ID, onReward, onError, onSkip }: UseAdsgramOptions) {
  const controllerRef = useRef<AdController | null>(null);

  useEffect(() => {
    return () => {
      controllerRef.current?.destroy();
      controllerRef.current = null;
    };
  }, [blockId]);

  const showAd = useCallback(async () => {
    if (!window.Adsgram) {
      onError?.("Adsgram SDK not loaded. Please try again.");
      return;
    }

    try {
      controllerRef.current?.destroy();
      const controller = window.Adsgram.init({ blockId });
      controllerRef.current = controller;

      const result = await controller.show();

      if (result.done && !result.error) {
        await onReward();
      } else if (!result.done && !result.error) {
        onSkip?.();
      } else if (result.error) {
        onError?.(result.description ?? "Ad failed to load.");
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Ad unavailable. Try again later.";
      onError?.(message);
    }
  }, [blockId, onReward, onError, onSkip]);

  return { showAd };
}
