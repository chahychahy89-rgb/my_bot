import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { getTelegramUser, type TelegramUser } from "./telegram";

const UserContext = createContext<TelegramUser>({
  telegramId: "demo123",
  firstName: "Demo Miner",
  username: "demo_miner",
  isReal: false,
});

export function UserProvider({ children }: { children: ReactNode }) {
  const [user] = useState<TelegramUser>(() => getTelegramUser());

  return <UserContext.Provider value={user}>{children}</UserContext.Provider>;
}

export function useTelegramUser(): TelegramUser {
  return useContext(UserContext);
}
