declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string;
        initDataUnsafe: {
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            language_code?: string;
          };
          start_param?: string;
        };
        ready: () => void;
        expand: () => void;
        close: () => void;
        MainButton: {
          text: string;
          show: () => void;
          hide: () => void;
          onClick: (fn: () => void) => void;
        };
        BackButton: {
          show: () => void;
          hide: () => void;
          onClick: (fn: () => void) => void;
        };
        colorScheme: "light" | "dark";
        themeParams: Record<string, string>;
        isExpanded: boolean;
        viewportHeight: number;
        viewportStableHeight: number;
        platform: string;
        version: string;
      };
    };
  }
}

export interface TelegramUser {
  telegramId: string;
  firstName: string;
  username: string;
  isReal: boolean;
}

export function getTelegramUser(): TelegramUser {
  const tg = window.Telegram?.WebApp;

  if (tg?.initDataUnsafe?.user) {
    const user = tg.initDataUnsafe.user;
    tg.ready();
    tg.expand();
    return {
      telegramId: String(user.id),
      firstName: user.first_name,
      username: user.username ?? `user${user.id}`,
      isReal: true,
    };
  }

  return {
    telegramId: "demo123",
    firstName: "Demo Miner",
    username: "demo_miner",
    isReal: false,
  };
}

export function isTelegramApp(): boolean {
  return !!(window.Telegram?.WebApp?.initDataUnsafe?.user);
}
