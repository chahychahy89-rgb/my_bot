let _username = "Mynewsafe77_bot";

export function setBotUsername(username: string) {
  _username = username;
}

export function getBotUsername(): string {
  return _username;
}
