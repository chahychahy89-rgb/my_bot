import TelegramBot from "node-telegram-bot-api";
import { logger } from "./logger";
import { db } from "@workspace/db";
import { usersTable, miningSessionsTable } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";
import { nanoid } from "nanoid";
import { setBotUsername } from "./botInfo";

const INVITER_REWARD = 1000;
const WELCOME_REWARD = 500;

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;

let bot: TelegramBot | null = null;

// ─── Level config ────────────────────────────────────────────────────────────

const LEVEL_NAMES: Record<number, string> = {
  1: "Rookie Miner",
  2: "Stone Breaker",
  3: "Iron Miner",
  4: "Gold Digger",
  5: "Diamond Seeker",
  6: "Crystal Master",
  7: "Gem Lord",
  8: "Vault Guardian",
  9: "Mining Legend",
  10: "Crypto King",
};

const LEVEL_THRESHOLDS = [0, 1000, 5000, 15000, 40000, 100000, 250000, 500000, 1000000, 2500000];

function getLevelName(level: number) {
  return LEVEL_NAMES[Math.max(1, Math.min(level, 10))] ?? "Mining Master";
}

function calcLevel(totalCoins: number): { level: number; next: number; progress: number } {
  let level = 1;
  for (let i = LEVEL_THRESHOLDS.length - 1; i >= 0; i--) {
    if (totalCoins >= LEVEL_THRESHOLDS[i]) { level = i + 1; break; }
  }
  level = Math.min(level, 10);
  const next = LEVEL_THRESHOLDS[level] ?? Infinity;
  const prev = LEVEL_THRESHOLDS[level - 1] ?? 0;
  const progress = next === Infinity ? 100 : Math.floor(((totalCoins - prev) / (next - prev)) * 100);
  return { level, next, progress };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function generateReferralCode(): string {
  return nanoid(8).toUpperCase();
}

function progressBar(percent: number, length = 10): string {
  const filled = Math.round((percent / 100) * length);
  return "█".repeat(filled) + "░".repeat(length - filled);
}

function rankEmoji(rank: number): string {
  return rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `${rank}.`;
}

async function getOrCreateUser(telegramId: string, username: string, firstName: string) {
  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });
  if (user) return user;

  const [newUser] = await db.insert(usersTable).values({
    telegramId,
    username: username || `user_${telegramId.slice(0, 6)}`,
    firstName: firstName || "Miner",
    referralCode: generateReferralCode(),
    totalCoins: "0",
    diamonds: "0",
    level: 1,
  }).returning();

  await db.insert(miningSessionsTable).values({
    telegramId,
    isActive: false,
    baseCoinsPerHour: "100",
    pendingCoins: "0",
    sessionDurationHours: 8,
  });

  return newUser;
}

function calcMiningStatus(session: typeof miningSessionsTable.$inferSelect) {
  if (!session.isActive || !session.startedAt) {
    return {
      pendingCoins: 0,
      progressPercent: 0,
      hoursRemaining: 0,
      isBoosted: false,
      coinsPerHour: parseFloat(session.baseCoinsPerHour),
    };
  }
  const now = new Date();
  const maxMs = session.sessionDurationHours * 3600 * 1000;
  const elapsed = Math.min(now.getTime() - session.startedAt.getTime(), maxMs);
  const elapsedHours = elapsed / 3600000;
  const progressPercent = Math.min((elapsed / maxMs) * 100, 100);
  const hoursRemaining = Math.max(session.sessionDurationHours - elapsedHours, 0);
  const isBoosted = !!(session.boostedUntil && session.boostedUntil > now);
  const baseRate = parseFloat(session.baseCoinsPerHour);
  let coins = 0;
  if (isBoosted && session.boostedUntil && session.startedAt) {
    const boostEnd = session.boostedUntil < now ? session.boostedUntil : now;
    const boostedMs = Math.min(boostEnd.getTime() - session.startedAt.getTime(), maxMs);
    const boostedHrs = boostedMs / 3600000;
    const normalHrs = Math.max(elapsedHours - boostedHrs, 0);
    coins = boostedHrs * baseRate * 2 + normalHrs * baseRate;
  } else {
    coins = elapsedHours * baseRate;
  }
  return {
    pendingCoins: Math.floor(coins * 100) / 100,
    progressPercent: Math.floor(progressPercent),
    hoursRemaining: Math.floor(hoursRemaining * 10) / 10,
    isBoosted,
    coinsPerHour: baseRate * (isBoosted ? 2 : 1),
  };
}

// ─── Main keyboard ────────────────────────────────────────────────────────────

function mainKeyboard(appUrl: string | null): TelegramBot.InlineKeyboardMarkup {
  return {
    inline_keyboard: [
      appUrl
        ? [{ text: "⛏ Open Mining App", web_app: { url: appUrl } }]
        : [{ text: "⛏ Open Mining App", callback_data: "open_app" }],
      [
        { text: "⛏ Mine", callback_data: "cmd_mine" },
        { text: "💰 Balance", callback_data: "cmd_balance" },
      ],
      [
        { text: "🏆 Leaderboard", callback_data: "cmd_top" },
        { text: "👥 Referral", callback_data: "cmd_referral" },
      ],
      [
        { text: "✅ Tasks", callback_data: "cmd_tasks" },
        { text: "❓ Help", callback_data: "cmd_help" },
      ],
    ],
  };
}

// ─── Bot init ────────────────────────────────────────────────────────────────

export function startTelegramBot() {
  if (!TOKEN) {
    logger.warn("TELEGRAM_BOT_TOKEN not set — bot will not start");
    return;
  }

  try {
    bot = new TelegramBot(TOKEN, { polling: true });
    logger.info("Telegram bot started (polling mode)");
    bot.getMe().then((info) => {
      if (info.username) setBotUsername(info.username);
      logger.info({ username: info.username }, "Bot username cached");
    }).catch(() => {});
  } catch (err) {
    logger.error({ err }, "Failed to start Telegram bot");
    return;
  }

  // Register command menu with Telegram
  bot.setMyCommands([
    { command: "start",    description: "Open the mining app dashboard" },
    { command: "mine",     description: "⛏ Start mining or collect coins" },
    { command: "balance",  description: "💰 Check your coins, diamonds & level" },
    { command: "top",      description: "🏆 View top 10 miners leaderboard" },
    { command: "referral", description: "👥 Get your referral link" },
    { command: "tasks",    description: "✅ View daily tasks & quests" },
    { command: "help",     description: "❓ Show all commands" },
  ]).catch((err) => logger.error({ err }, "Failed to set bot commands"));

  bot.on("polling_error", (err) => {
    logger.error({ err: err.message }, "Telegram polling error");
  });

  // ─── /start ─────────────────────────────────────────────────────────────
  bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from?.id ?? chatId);
    const username = msg.from?.username ?? "user";
    const firstName = msg.from?.first_name ?? "Miner";
    const referralParam = match?.[1]?.trim();
    try {
      const user = await getOrCreateUser(telegramId, username, firstName);
      await handleReferralJoin(chatId, telegramId, username, firstName, referralParam, user);
      const domains = process.env.REPLIT_DOMAINS?.split(",")[0];
      const appUrl = domains ? `https://${domains}` : null;
      const coins = Math.floor(parseFloat(user.totalCoins));
      const { level } = calcLevel(coins);
      await bot?.sendMessage(chatId,
        `*Welcome, ${firstName}!* ⛏\n\n` +
        `💰 Coins: *${coins.toLocaleString()}*\n` +
        `⭐ Level: *${level} — ${getLevelName(level)}*\n\n` +
        `Tap *Open Mining App* for the full experience, or use quick buttons below!`,
        { parse_mode: "Markdown", reply_markup: mainKeyboard(appUrl) }
      );
    } catch (err) {
      logger.error({ err }, "Error in /start");
      bot?.sendMessage(chatId, "Something went wrong. Please try again.");
    }
  });

  // ─── /mine ──────────────────────────────────────────────────────────────
  bot.onText(/\/mine/, async (msg) => {
    const { id: chatId, id: _ } = msg.chat;
    const telegramId = String(msg.from?.id ?? chatId);
    await handleMineCommand(chatId, telegramId, msg.from?.username ?? "user", msg.from?.first_name ?? "Miner");
  });

  // ─── /balance ───────────────────────────────────────────────────────────
  bot.onText(/\/balance/, async (msg) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from?.id ?? chatId);
    await handleBalanceCommand(chatId, telegramId, msg.from?.username ?? "user", msg.from?.first_name ?? "Miner");
  });

  // ─── /top ───────────────────────────────────────────────────────────────
  bot.onText(/\/top/, async (msg) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from?.id ?? chatId);
    await handleTopCommand(chatId, telegramId);
  });

  // ─── /referral ──────────────────────────────────────────────────────────
  bot.onText(/\/referral/, async (msg) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from?.id ?? chatId);
    await handleReferralCommand(chatId, telegramId, msg.from?.username ?? "user", msg.from?.first_name ?? "Miner");
  });

  // ─── /tasks ─────────────────────────────────────────────────────────────
  bot.onText(/\/tasks/, async (msg) => {
    const chatId = msg.chat.id;
    const telegramId = String(msg.from?.id ?? chatId);
    await handleTasksCommand(chatId, telegramId, msg.from?.username ?? "user", msg.from?.first_name ?? "Miner");
  });

  // ─── /help ──────────────────────────────────────────────────────────────
  bot.onText(/\/help/, async (msg) => {
    await handleHelpCommand(msg.chat.id);
  });

  // ─── Inline button callbacks ─────────────────────────────────────────────
  bot.on("callback_query", async (query) => {
    const chatId = query.message?.chat.id;
    const telegramId = String(query.from.id);
    const username = query.from.username ?? "user";
    const firstName = query.from.first_name ?? "Miner";
    if (!chatId) return;
    await bot?.answerCallbackQuery(query.id).catch(() => {});

    switch (query.data) {
      case "cmd_mine":     await handleMineCommand(chatId, telegramId, username, firstName); break;
      case "cmd_balance":  await handleBalanceCommand(chatId, telegramId, username, firstName); break;
      case "cmd_top":      await handleTopCommand(chatId, telegramId); break;
      case "cmd_referral": await handleReferralCommand(chatId, telegramId, username, firstName); break;
      case "cmd_tasks":    await handleTasksCommand(chatId, telegramId, username, firstName); break;
      case "cmd_help":     await handleHelpCommand(chatId); break;
      case "mine_start":   await handleMineStart(chatId, telegramId, username, firstName); break;
      case "mine_collect": await handleMineCollect(chatId, telegramId, username, firstName); break;
      case "mine_status":  await handleMineCommand(chatId, telegramId, username, firstName); break;
      case "open_app":
        await bot?.sendMessage(chatId,
          "The app will be available after publishing. Use `/mine`, `/balance`, or `/top` in the meantime!",
          { parse_mode: "Markdown" }
        );
        break;
    }
  });

  return bot;
}

// ─── Referral join helper ─────────────────────────────────────────────────────

async function handleReferralJoin(
  chatId: number,
  telegramId: string,
  username: string,
  firstName: string,
  referralParam: string | undefined,
  user: Awaited<ReturnType<typeof getOrCreateUser>>
) {
  if (!referralParam || referralParam === user.referralCode || user.referredBy) return;
  const referrer = await db.query.usersTable.findFirst({ where: eq(usersTable.referralCode, referralParam) });
  if (!referrer) return;
  const { referralsTable } = await import("@workspace/db");
  const existing = await db.query.referralsTable.findFirst({
    where: eq(referralsTable.refereeTelegramId, telegramId),
  });
  if (existing) return;
  await db.insert(referralsTable).values({
    referrerTelegramId: referrer.telegramId,
    refereeTelegramId: telegramId,
    refereeUsername: username,
    refereeFirstName: firstName,
    rewardAmount: INVITER_REWARD.toString(),
  });
  // Reward inviter
  const newTotal = parseFloat(referrer.totalCoins) + INVITER_REWARD;
  const newEarnings = parseFloat(referrer.referralEarnings) + INVITER_REWARD;
  await db.update(usersTable)
    .set({ totalCoins: newTotal.toString(), referralEarnings: newEarnings.toString() })
    .where(eq(usersTable.telegramId, referrer.telegramId));
  // Give welcome reward to new user
  const joinUser = await db.query.usersTable.findFirst({ where: eq(usersTable.telegramId, telegramId) });
  if (joinUser) {
    await db.update(usersTable)
      .set({ totalCoins: (parseFloat(joinUser.totalCoins) + WELCOME_REWARD).toString() })
      .where(eq(usersTable.telegramId, telegramId));
  }
  await db.update(usersTable)
    .set({ referredBy: referrer.referralCode })
    .where(eq(usersTable.telegramId, telegramId));
  bot?.sendMessage(referrer.telegramId,
    `⛏ *${firstName}* joined via your referral!\n🎉 +${INVITER_REWARD} coins added to your balance!`,
    { parse_mode: "Markdown" }
  ).catch(() => {});
  bot?.sendMessage(chatId,
    `🎁 Welcome gift! You received *+${WELCOME_REWARD} coins* for joining via referral!`,
    { parse_mode: "Markdown" }
  ).catch(() => {});
}

// ─── /mine handler ────────────────────────────────────────────────────────────

async function handleMineCommand(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    await getOrCreateUser(telegramId, username, firstName);
    let session = await db.query.miningSessionsTable.findFirst({
      where: eq(miningSessionsTable.telegramId, telegramId),
    });
    if (!session) {
      [session] = await db.insert(miningSessionsTable).values({
        telegramId, isActive: false, baseCoinsPerHour: "100", pendingCoins: "0", sessionDurationHours: 8,
      }).returning();
    }
    const { pendingCoins, progressPercent, hoursRemaining, isBoosted, coinsPerHour } = calcMiningStatus(session);

    if (!session.isActive) {
      await bot?.sendMessage(chatId,
        `*Mining Status* ⛏\n\n` +
        `Status: *Idle — ready to mine*\n` +
        `Rate: *100 coins/hour*\n` +
        `Session duration: *8 hours*\n\n` +
        `Start mining to earn coins automatically. Come back any time to collect!`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "⛏ Start Mining", callback_data: "mine_start" }]] },
        }
      );
      return;
    }

    const bar = progressBar(progressPercent);
    const boostLabel = isBoosted ? " ⚡ BOOSTED" : "";
    const isDone = progressPercent >= 100;

    const buttons: TelegramBot.InlineKeyboardButton[][] = [];
    if (pendingCoins > 0) {
      buttons.push([{ text: `💰 Collect ${Math.floor(pendingCoins).toLocaleString()} coins`, callback_data: "mine_collect" }]);
    }
    buttons.push([{ text: "🔄 Refresh", callback_data: "mine_status" }]);

    await bot?.sendMessage(chatId,
      `*Mining Status* ⛏${boostLabel}\n\n` +
      `\`${bar}\` *${progressPercent}%*\n\n` +
      `⏱ Time left: *${hoursRemaining}h*\n` +
      `💰 Pending: *${Math.floor(pendingCoins).toLocaleString()} coins*\n` +
      `⚡ Rate: *${coinsPerHour} coins/hour*\n\n` +
      (isDone
        ? `✅ Session complete! Collect your coins and start a new session.`
        : `Mining in progress... collect anytime or wait for full session.\n\n_Tip: Open the app to watch an ad for 2x speed!_`),
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: buttons } }
    );
  } catch (err) {
    logger.error({ err }, "Error in /mine");
    bot?.sendMessage(chatId, "Could not fetch mining status. Please try again.");
  }
}

async function handleMineStart(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    await getOrCreateUser(telegramId, username, firstName);
    const now = new Date();
    const existing = await db.query.miningSessionsTable.findFirst({
      where: eq(miningSessionsTable.telegramId, telegramId),
    });
    if (existing?.isActive) {
      await handleMineCommand(chatId, telegramId, username, firstName);
      return;
    }
    if (existing) {
      await db.update(miningSessionsTable)
        .set({ isActive: true, startedAt: now, pendingCoins: "0", lastUpdatedAt: now })
        .where(eq(miningSessionsTable.telegramId, telegramId));
    } else {
      await db.insert(miningSessionsTable).values({
        telegramId, isActive: true, startedAt: now, baseCoinsPerHour: "100",
        pendingCoins: "0", sessionDurationHours: 8, lastUpdatedAt: now,
      });
    }
    await bot?.sendMessage(chatId,
      `*Mining Started!* ⛏\n\n` +
      `Your miner is now active — earning *100 coins/hour*.\n` +
      `Session duration: *8 hours*\n\n` +
      `Come back anytime to check progress or collect early!\n` +
      `_Open the web app to get a 2x boost._`,
      {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: [[{ text: "📊 Check Status", callback_data: "mine_status" }]] },
      }
    );
  } catch (err) {
    logger.error({ err }, "Error starting mine");
    bot?.sendMessage(chatId, "Could not start mining. Please try again.");
  }
}

async function handleMineCollect(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    const session = await db.query.miningSessionsTable.findFirst({
      where: eq(miningSessionsTable.telegramId, telegramId),
    });
    if (!session?.isActive) {
      await bot?.sendMessage(chatId, "No active mining session. Use /mine to start one!");
      return;
    }
    const { pendingCoins } = calcMiningStatus(session);
    if (pendingCoins <= 0) {
      await bot?.sendMessage(chatId, "Nothing to collect yet — mining is still in progress. Check back soon!");
      return;
    }
    const user = await getOrCreateUser(telegramId, username, firstName);
    const oldTotal = parseFloat(user.totalCoins);
    const newTotal = oldTotal + pendingCoins;
    const { level: newLevel } = calcLevel(newTotal);
    const leveledUp = newLevel > user.level;

    await db.update(usersTable)
      .set({ totalCoins: newTotal.toString(), level: newLevel })
      .where(eq(usersTable.telegramId, telegramId));
    await db.update(miningSessionsTable)
      .set({ isActive: false, pendingCoins: "0", lastUpdatedAt: new Date() })
      .where(eq(miningSessionsTable.telegramId, telegramId));

    let text =
      `*Coins Collected!* 💰\n\n` +
      `+${Math.floor(pendingCoins).toLocaleString()} coins\n` +
      `New balance: *${Math.floor(newTotal).toLocaleString()} coins*\n`;
    if (leveledUp) {
      text += `\n🎉 *Level Up!* You are now Level ${newLevel} — ${getLevelName(newLevel)}!\n`;
    }
    text += `\nReady to mine again?`;

    await bot?.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "⛏ Start New Session", callback_data: "mine_start" }]] },
    });
  } catch (err) {
    logger.error({ err }, "Error collecting mine");
    bot?.sendMessage(chatId, "Could not collect coins. Please try again.");
  }
}

// ─── /balance handler ─────────────────────────────────────────────────────────

async function handleBalanceCommand(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    const user = await getOrCreateUser(telegramId, username, firstName);
    const coins = Math.floor(parseFloat(user.totalCoins));
    const { level, next, progress } = calcLevel(coins);
    const levelName = getLevelName(level);
    const bar = progressBar(progress, 8);
    const { referralsTable } = await import("@workspace/db");
    const referrals = await db.query.referralsTable.findMany({
      where: eq(referralsTable.referrerTelegramId, telegramId),
    });

    // Active session?
    const session = await db.query.miningSessionsTable.findFirst({
      where: eq(miningSessionsTable.telegramId, telegramId),
    });
    const miningStatus = session ? calcMiningStatus(session) : null;
    const miningLine = miningStatus?.pendingCoins
      ? `⛏ Mining: *+${Math.floor(miningStatus.pendingCoins).toLocaleString()} pending*`
      : session?.isActive
        ? `⛏ Mining: *Active (${miningStatus?.progressPercent}%)*`
        : `⛏ Mining: *Idle*`;

    await bot?.sendMessage(chatId,
      `*Your Mining Profile* ⛏\n\n` +
      `👤 Name: *${user.firstName}*\n` +
      `⭐ Level: *${level} — ${levelName}*\n` +
      `\`${bar}\` ${progress}%${next !== Infinity ? ` (${(next - coins).toLocaleString()} to next)` : ""}\n\n` +
      `💰 Coins: *${coins.toLocaleString()}*\n` +
      `💎 Diamonds: *${parseFloat(user.diamonds).toFixed(1)}*\n` +
      `👥 Referrals: *${referrals.length} friends*\n` +
      `🏅 Referral earnings: *${Math.floor(parseFloat(user.referralEarnings)).toLocaleString()} coins*\n\n` +
      miningLine + `\n\n` +
      `Referral Code: \`${user.referralCode}\``,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    logger.error({ err }, "Error in /balance");
    bot?.sendMessage(chatId, "Could not fetch balance. Please try again.");
  }
}

// ─── /top handler ────────────────────────────────────────────────────────────

async function handleTopCommand(chatId: number, requesterId: string) {
  try {
    const topUsers = await db
      .select()
      .from(usersTable)
      .orderBy(desc(sql`${usersTable.totalCoins}::numeric`))
      .limit(10);

    if (topUsers.length === 0) {
      await bot?.sendMessage(chatId, "No miners yet! Be the first to start mining.");
      return;
    }

    const requesterRank = await db
      .select({ rank: sql<number>`count(*)` })
      .from(usersTable)
      .where(sql`${usersTable.totalCoins}::numeric > (select total_coins::numeric from users where telegram_id = ${requesterId})`);

    const myRank = Number(requesterRank[0]?.rank ?? 0) + 1;
    const isInTop = myRank <= 10;

    const lines = topUsers.map((u, i) => {
      const rank = i + 1;
      const name = u.firstName.length > 12 ? u.firstName.slice(0, 12) + "…" : u.firstName;
      const coins = Math.floor(parseFloat(u.totalCoins)).toLocaleString();
      const isMe = u.telegramId === requesterId;
      const star = isMe ? " ← you" : "";
      return `${rankEmoji(rank)} *${name}*${star}\n   💰 ${coins} coins · Lv.${u.level}`;
    });

    let footer = "";
    if (!isInTop) {
      footer = `\n\n_Your rank: #${myRank} — keep mining to climb!_`;
    }

    await bot?.sendMessage(chatId,
      `*🏆 Top 10 Miners*\n\n` + lines.join("\n\n") + footer,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Refresh", callback_data: "cmd_top" },
              { text: "⛏ Mine Now", callback_data: "cmd_mine" },
            ],
          ],
        },
      }
    );
  } catch (err) {
    logger.error({ err }, "Error in /top");
    bot?.sendMessage(chatId, "Could not fetch leaderboard. Please try again.");
  }
}

// ─── /referral handler ───────────────────────────────────────────────────────

async function handleReferralCommand(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    const user = await getOrCreateUser(telegramId, username, firstName);
    const botInfo = await bot?.getMe();
    const botUsername = botInfo?.username ?? "YourMiningBot";
    const referralLink = `https://t.me/${botUsername}?start=${user.referralCode}`;

    const { referralsTable } = await import("@workspace/db");
    const referrals = await db.query.referralsTable.findMany({
      where: eq(referralsTable.referrerTelegramId, telegramId),
    });

    const MILESTONES = [
      { count: 1,  label: "First Recruit",  reward: "+1000 coins" },
      { count: 3,  label: "Mining Squad",   reward: "+2 diamonds" },
      { count: 5,  label: "Golden Key",     reward: "+1 diamond" },
      { count: 10, label: "Empire Builder", reward: "+5 diamonds" },
      { count: 25, label: "Mining Legend",  reward: "+15 diamonds" },
    ];

    const milestoneLines = MILESTONES.map((m) => {
      const done = referrals.length >= m.count;
      return `${done ? "✅" : "⬜"} ${m.count} friends → *${m.label}* (${m.reward})`;
    }).join("\n");

    const next = MILESTONES.find((m) => referrals.length < m.count);
    const nextLine = next
      ? `\n📍 Next: invite *${next.count - referrals.length}* more friend(s) for *${next.label}*!`
      : `\n🎉 All milestones unlocked! Keep inviting for coins.`;

    const friendList = referrals.length > 0
      ? `\n*Recent Friends:*\n` + referrals.slice(0, 5).map((r) => `• ${r.refereeFirstName}`).join("\n")
      : "";

    await bot?.sendMessage(chatId,
      `*Referral Program* 👥\n\n` +
      `👥 Friends: *${referrals.length}*\n` +
      `💰 Earned: *${Math.floor(parseFloat(user.referralEarnings)).toLocaleString()} coins*\n\n` +
      `*Milestones:*\n${milestoneLines}\n${nextLine}\n` +
      friendList + `\n\n` +
      `*Your Link:*\n\`${referralLink}\`\n\n` +
      `_Each friend earns you +1000 coins! They get +500 welcome gift!_`,
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    logger.error({ err }, "Error in /referral");
    bot?.sendMessage(chatId, "Could not fetch referral info. Please try again.");
  }
}

// ─── /tasks handler ──────────────────────────────────────────────────────────

async function handleTasksCommand(chatId: number, telegramId: string, username: string, firstName: string) {
  try {
    await getOrCreateUser(telegramId, username, firstName);
    const { taskDefinitionsTable, userTaskCompletionsTable } = await import("@workspace/db");
    const tasks = await db.query.taskDefinitionsTable.findMany();
    if (tasks.length === 0) {
      await bot?.sendMessage(chatId, "No tasks available yet. Check back soon!");
      return;
    }
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const completions = await db.query.userTaskCompletionsTable.findMany({
      where: eq(userTaskCompletionsTable.telegramId, telegramId),
    });

    let completed = 0;
    const taskLines = tasks.map((task) => {
      const done = completions.find((c) => {
        if (c.taskId !== task.id) return false;
        return task.isDaily ? c.completedAt >= today : true;
      });
      if (done) completed++;
      const status = done ? "✅" : "⬜";
      const reward = `+${parseFloat(task.reward)} ${task.rewardType}`;
      return `${status} *${task.title}*\n   ${task.description} — _${reward}_`;
    });

    const domains = process.env.REPLIT_DOMAINS?.split(",")[0];
    const appUrl = domains ? `https://${domains}` : null;

    await bot?.sendMessage(chatId,
      `*Daily Quests* ✅\n\n` +
      taskLines.join("\n\n") + `\n\n` +
      `Progress: *${completed}/${tasks.length}* tasks done\n` +
      `\`${progressBar((completed / tasks.length) * 100, 8)}\`\n\n` +
      (appUrl
        ? `Open the app to complete tasks:\n${appUrl}`
        : `_Open the web app to complete tasks and claim your rewards!_`),
      { parse_mode: "Markdown" }
    );
  } catch (err) {
    logger.error({ err }, "Error in /tasks");
    bot?.sendMessage(chatId, "Could not fetch tasks. Please try again.");
  }
}

// ─── /help handler ───────────────────────────────────────────────────────────

async function handleHelpCommand(chatId: number) {
  await bot?.sendMessage(chatId,
    `*⛏ Mining Bot — Command Guide*\n\n` +
    `/start — Welcome screen & quick menu\n` +
    `/mine — Start mining or collect coins\n` +
    `/balance — Your coins, diamonds & level\n` +
    `/top — 🏆 Top 10 miners leaderboard\n` +
    `/referral — Your link & invite milestones\n` +
    `/tasks — Daily quests & rewards\n` +
    `/help — This help message\n\n` +
    `*Pro Tips:*\n` +
    `⛏ Mining runs for 8h automatically\n` +
    `👥 Each referral = +500 coins instantly\n` +
    `⚡ 2x boost available in the web app\n` +
    `✅ Complete daily tasks for diamonds\n` +
    `🏆 Reach Level 10 to become Crypto King`,
    { parse_mode: "Markdown" }
  );
}

// ─── Cleanup ──────────────────────────────────────────────────────────────────

export function stopTelegramBot() {
  bot?.stopPolling();
  bot = null;
}
