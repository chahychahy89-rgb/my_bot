import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, miningSessionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

function calculatePendingCoins(session: {
  startedAt: Date | null;
  boostedUntil: Date | null;
  baseCoinsPerHour: string;
  lastUpdatedAt: Date;
  sessionDurationHours: number;
  isActive: boolean;
}): { pendingCoins: number; progressPercent: number; hoursRemaining: number } {
  if (!session.isActive || !session.startedAt) {
    return { pendingCoins: 0, progressPercent: 0, hoursRemaining: 0 };
  }

  const now = new Date();
  const startedAt = session.startedAt;
  const maxDuration = session.sessionDurationHours * 60 * 60 * 1000;
  const elapsed = Math.min(now.getTime() - startedAt.getTime(), maxDuration);
  const elapsedHours = elapsed / (60 * 60 * 1000);
  const progressPercent = Math.min((elapsed / maxDuration) * 100, 100);
  const hoursRemaining = Math.max(session.sessionDurationHours - elapsedHours, 0);

  const baseRate = parseFloat(session.baseCoinsPerHour);

  let coins = 0;
  if (session.boostedUntil && session.boostedUntil > startedAt) {
    const boostEnd = session.boostedUntil < now ? session.boostedUntil : now;
    const boostedElapsedMs = Math.min(boostEnd.getTime() - startedAt.getTime(), maxDuration);
    const boostedHours = boostedElapsedMs / (60 * 60 * 1000);
    const normalHours = elapsedHours - boostedHours;
    coins = boostedHours * baseRate * 2 + Math.max(normalHours, 0) * baseRate;
  } else {
    coins = elapsedHours * baseRate;
  }

  return {
    pendingCoins: Math.floor(coins * 100) / 100,
    progressPercent: Math.floor(progressPercent * 100) / 100,
    hoursRemaining: Math.floor(hoursRemaining * 100) / 100,
  };
}

router.get("/:telegramId/status", async (req, res) => {
  const { telegramId } = req.params;

  let session = await db.query.miningSessionsTable.findFirst({
    where: eq(miningSessionsTable.telegramId, telegramId),
  });

  if (!session) {
    const [newSession] = await db.insert(miningSessionsTable).values({
      telegramId,
      isActive: false,
      baseCoinsPerHour: "100",
      pendingCoins: "0",
      sessionDurationHours: 8,
    }).returning();
    session = newSession;
  }

  const { pendingCoins, progressPercent, hoursRemaining } = calculatePendingCoins(session);
  const isBoosted = !!(session.boostedUntil && session.boostedUntil > new Date());
  const coinsPerHour = parseFloat(session.baseCoinsPerHour) * (isBoosted ? 2 : 1);

  res.json({
    isActive: session.isActive,
    startedAt: session.startedAt?.toISOString() ?? null,
    boostedUntil: session.boostedUntil?.toISOString() ?? null,
    isBoosted,
    coinsPerHour,
    pendingCoins,
    progressPercent,
    hoursRemaining,
  });
});

router.post("/:telegramId/start", async (req, res) => {
  const { telegramId } = req.params;

  let session = await db.query.miningSessionsTable.findFirst({
    where: eq(miningSessionsTable.telegramId, telegramId),
  });

  const now = new Date();

  if (!session) {
    const [newSession] = await db.insert(miningSessionsTable).values({
      telegramId,
      isActive: true,
      startedAt: now,
      baseCoinsPerHour: "100",
      pendingCoins: "0",
      sessionDurationHours: 8,
      lastUpdatedAt: now,
    }).returning();
    session = newSession;
  } else {
    const [updated] = await db.update(miningSessionsTable)
      .set({ isActive: true, startedAt: now, pendingCoins: "0", lastUpdatedAt: now })
      .where(eq(miningSessionsTable.telegramId, telegramId))
      .returning();
    session = updated;
  }

  const isBoosted = !!(session.boostedUntil && session.boostedUntil > now);

  res.json({
    isActive: true,
    startedAt: now.toISOString(),
    boostedUntil: session.boostedUntil?.toISOString() ?? null,
    isBoosted,
    coinsPerHour: parseFloat(session.baseCoinsPerHour) * (isBoosted ? 2 : 1),
    pendingCoins: 0,
    progressPercent: 0,
    hoursRemaining: session.sessionDurationHours,
  });
});

router.post("/:telegramId/boost", async (req, res) => {
  const { telegramId } = req.params;

  const session = await db.query.miningSessionsTable.findFirst({
    where: eq(miningSessionsTable.telegramId, telegramId),
  });

  const now = new Date();
  const boostedUntil = new Date(now.getTime() + 60 * 60 * 1000);

  const { pendingCoins } = session ? calculatePendingCoins(session) : { pendingCoins: 0 };

  const [updated] = await db.update(miningSessionsTable)
    .set({
      boostedUntil,
      lastUpdatedAt: now,
      pendingCoins: pendingCoins.toString(),
    })
    .where(eq(miningSessionsTable.telegramId, telegramId))
    .returning();

  const baseRate = parseFloat(updated.baseCoinsPerHour);

  res.json({
    isActive: updated.isActive,
    startedAt: updated.startedAt?.toISOString() ?? null,
    boostedUntil: boostedUntil.toISOString(),
    isBoosted: true,
    coinsPerHour: baseRate * 2,
    pendingCoins,
    progressPercent: session ? calculatePendingCoins(updated).progressPercent : 0,
    hoursRemaining: session ? calculatePendingCoins(updated).hoursRemaining : 0,
  });
});

router.post("/:telegramId/collect", async (req, res) => {
  const { telegramId } = req.params;

  const session = await db.query.miningSessionsTable.findFirst({
    where: eq(miningSessionsTable.telegramId, telegramId),
  });

  if (!session || !session.isActive) {
    res.json({ collectedCoins: 0, newTotal: 0, message: "No active mining session" });
    return;
  }

  const { pendingCoins } = calculatePendingCoins(session);

  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  const currentTotal = parseFloat(user?.totalCoins ?? "0");
  const newTotal = currentTotal + pendingCoins;

  await db.update(usersTable)
    .set({ totalCoins: newTotal.toString() })
    .where(eq(usersTable.telegramId, telegramId));

  await db.update(miningSessionsTable)
    .set({ isActive: false, pendingCoins: "0", lastUpdatedAt: new Date() })
    .where(eq(miningSessionsTable.telegramId, telegramId));

  res.json({
    collectedCoins: pendingCoins,
    newTotal,
    message: `You collected ${Math.floor(pendingCoins)} coins!`,
  });
});

export default router;
