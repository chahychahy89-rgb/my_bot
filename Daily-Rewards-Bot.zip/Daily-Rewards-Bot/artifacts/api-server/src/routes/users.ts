import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, miningSessionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { nanoid } from "nanoid";

const router = Router();

function generateReferralCode(): string {
  return nanoid(8).toUpperCase();
}

function calculateLevel(totalCoins: number): number {
  if (totalCoins >= 1000000) return 10;
  if (totalCoins >= 500000) return 9;
  if (totalCoins >= 200000) return 8;
  if (totalCoins >= 100000) return 7;
  if (totalCoins >= 50000) return 6;
  if (totalCoins >= 20000) return 5;
  if (totalCoins >= 10000) return 4;
  if (totalCoins >= 5000) return 3;
  if (totalCoins >= 1000) return 2;
  return 1;
}

function nextLevelCoins(level: number): number {
  const thresholds = [0, 1000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000, 5000000];
  return thresholds[Math.min(level, thresholds.length - 1)] ?? 5000000;
}

router.get("/:telegramId", async (req, res) => {
  const { telegramId } = req.params;

  let user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  if (!user) {
    const referralCode = generateReferralCode();
    const [newUser] = await db.insert(usersTable).values({
      telegramId,
      username: `user_${telegramId.slice(0, 6)}`,
      firstName: "Miner",
      referralCode,
      totalCoins: "0",
      diamonds: "0",
      level: 1,
    }).returning();
    user = newUser;

    await db.insert(miningSessionsTable).values({
      telegramId,
      isActive: false,
      baseCoinsPerHour: "100",
      pendingCoins: "0",
      sessionDurationHours: 8,
    });
  }

  res.json({
    id: user.id,
    telegramId: user.telegramId,
    username: user.username,
    firstName: user.firstName,
    totalCoins: parseFloat(user.totalCoins),
    diamonds: parseFloat(user.diamonds),
    referralCode: user.referralCode,
    referredBy: user.referredBy ?? null,
    level: user.level,
    createdAt: user.createdAt.toISOString(),
  });
});

router.get("/:telegramId/balance", async (req, res) => {
  const { telegramId } = req.params;

  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const totalCoins = parseFloat(user.totalCoins);
  const level = calculateLevel(totalCoins);

  const referrals = await db.query.referralsTable.findMany({
    where: eq(
      (await import("@workspace/db")).referralsTable.referrerTelegramId,
      telegramId
    ),
  });

  const completions = await db.query.userTaskCompletionsTable.findMany({
    where: eq(
      (await import("@workspace/db")).userTaskCompletionsTable.telegramId,
      telegramId
    ),
  });

  res.json({
    totalCoins,
    diamonds: parseFloat(user.diamonds),
    level,
    nextLevelCoins: nextLevelCoins(level),
    referralCount: referrals.length,
    tasksCompleted: completions.length,
  });
});

const DAILY_AD_LIMIT = 20;

function todayUTC(): string {
  return new Date().toISOString().slice(0, 10); // "YYYY-MM-DD"
}

// GET /:telegramId/ad-status — returns today's ad count
router.get("/:telegramId/ad-status", async (req, res) => {
  const { telegramId } = req.params;
  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });
  if (!user) { res.status(404).json({ error: "User not found" }); return; }

  const today = todayUTC();
  const count = user.lastAdDate === today ? (user.dailyAdCount ?? 0) : 0;
  res.json({ dailyAdCount: count, dailyAdLimit: DAILY_AD_LIMIT, limitReached: count >= DAILY_AD_LIMIT });
});

// POST /:telegramId/ad-reward — give 500 coins after watching an ad (max 20/day)
router.post("/:telegramId/ad-reward", async (req, res) => {
  const { telegramId } = req.params;

  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const today = todayUTC();
  const currentCount = user.lastAdDate === today ? (user.dailyAdCount ?? 0) : 0;

  if (currentCount >= DAILY_AD_LIMIT) {
    res.status(429).json({
      success: false,
      limitReached: true,
      dailyAdCount: currentCount,
      dailyAdLimit: DAILY_AD_LIMIT,
      message: "Daily ad limit reached",
    });
    return;
  }

  const AD_REWARD = 500;
  const newTotal = parseFloat(user.totalCoins) + AD_REWARD;
  const newLevel = calculateLevel(newTotal);
  const newCount = currentCount + 1;

  await db.update(usersTable)
    .set({
      totalCoins: newTotal.toString(),
      level: newLevel,
      dailyAdCount: newCount,
      lastAdDate: today,
    })
    .where(eq(usersTable.telegramId, telegramId));

  res.json({
    success: true,
    rewardCoins: AD_REWARD,
    newTotal,
    level: newLevel,
    dailyAdCount: newCount,
    dailyAdLimit: DAILY_AD_LIMIT,
    limitReached: newCount >= DAILY_AD_LIMIT,
  });
});

export default router;
