import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, taskDefinitionsTable, userTaskCompletionsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

const DEFAULT_TASKS = [
  {
    id: "daily_checkin",
    title: "Daily Check-in",
    description: "Visit the bot every day to keep your streak alive",
    reward: "50",
    rewardType: "coins",
    taskType: "daily_checkin",
    icon: "Calendar",
    link: null,
    isDaily: true,
  },
  {
    id: "join_channel",
    title: "Join Official Channel",
    description: "Join our official Telegram channel to stay updated",
    reward: "500",
    rewardType: "coins",
    taskType: "join_channel",
    icon: "Send",
    link: "https://t.me/example_channel",
    isDaily: false,
  },
  {
    id: "share_screenshot",
    title: "Share Your Mining Progress",
    description: "Share a screenshot of your earnings in your story",
    reward: "200",
    rewardType: "coins",
    taskType: "share_screenshot",
    icon: "Share2",
    link: null,
    isDaily: true,
  },
  {
    id: "invite_1_friend",
    title: "Invite Your First Friend",
    description: "Invite a friend and unlock your mining potential",
    reward: "3",
    rewardType: "diamonds",
    taskType: "invite_friend",
    icon: "UserPlus",
    link: null,
    isDaily: false,
  },
  {
    id: "watch_ad",
    title: "Watch an Ad",
    description: "Watch a short video to boost your mining speed by 200%",
    reward: "100",
    rewardType: "coins",
    taskType: "watch_ad",
    icon: "Play",
    link: null,
    isDaily: true,
  },
];

async function ensureTasksExist() {
  for (const task of DEFAULT_TASKS) {
    const existing = await db.query.taskDefinitionsTable.findFirst({
      where: eq(taskDefinitionsTable.id, task.id),
    });
    if (!existing) {
      await db.insert(taskDefinitionsTable).values(task);
    }
  }
}

router.get("/:telegramId", async (req, res) => {
  const { telegramId } = req.params;

  await ensureTasksExist();

  const tasks = await db.query.taskDefinitionsTable.findMany();

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const completions = await db.query.userTaskCompletionsTable.findMany({
    where: eq(userTaskCompletionsTable.telegramId, telegramId),
  });

  const result = tasks.map((task) => {
    const completion = completions.find((c) => {
      if (c.taskId !== task.id) return false;
      if (task.isDaily) {
        return c.completedAt >= today;
      }
      return true;
    });

    return {
      id: task.id,
      title: task.title,
      description: task.description,
      reward: parseFloat(task.reward),
      rewardType: task.rewardType,
      taskType: task.taskType,
      isCompleted: !!completion,
      completedAt: completion?.completedAt?.toISOString() ?? null,
      icon: task.icon,
      link: task.link ?? null,
    };
  });

  res.json(result);
});

router.post("/:telegramId/:taskId/complete", async (req, res) => {
  const { telegramId, taskId } = req.params;

  const task = await db.query.taskDefinitionsTable.findFirst({
    where: eq(taskDefinitionsTable.id, taskId),
  });

  if (!task) {
    res.status(404).json({ success: false, reward: 0, rewardType: "coins", newTotal: 0, message: "Task not found" });
    return;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const alreadyCompleted = await db.query.userTaskCompletionsTable.findFirst({
    where: and(
      eq(userTaskCompletionsTable.telegramId, telegramId),
      eq(userTaskCompletionsTable.taskId, taskId),
    ),
  });

  if (alreadyCompleted) {
    if (!task.isDaily || alreadyCompleted.completedAt >= today) {
      res.json({ success: false, reward: 0, rewardType: task.rewardType, newTotal: 0, message: "Task already completed" });
      return;
    }
  }

  await db.insert(userTaskCompletionsTable).values({
    telegramId,
    taskId,
  });

  const reward = parseFloat(task.reward);
  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  let newTotal = 0;
  if (task.rewardType === "diamonds") {
    const current = parseFloat(user?.diamonds ?? "0");
    newTotal = current + reward;
    await db.update(usersTable)
      .set({ diamonds: newTotal.toString() })
      .where(eq(usersTable.telegramId, telegramId));
  } else {
    const current = parseFloat(user?.totalCoins ?? "0");
    newTotal = current + reward;
    await db.update(usersTable)
      .set({ totalCoins: newTotal.toString() })
      .where(eq(usersTable.telegramId, telegramId));
  }

  res.json({
    success: true,
    reward,
    rewardType: task.rewardType,
    newTotal,
    message: `You earned ${reward} ${task.rewardType}!`,
  });
});

export default router;
