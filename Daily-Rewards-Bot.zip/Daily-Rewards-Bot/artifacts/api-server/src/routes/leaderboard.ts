import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable } from "@workspace/db";
import { desc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const users = await db.query.usersTable.findMany({
    orderBy: [desc(usersTable.totalCoins)],
    limit: 20,
  });

  const leaderboard = users.map((user, index) => ({
    rank: index + 1,
    username: user.username,
    firstName: user.firstName,
    totalCoins: parseFloat(user.totalCoins),
    level: user.level,
  }));

  res.json(leaderboard);
});

export default router;
