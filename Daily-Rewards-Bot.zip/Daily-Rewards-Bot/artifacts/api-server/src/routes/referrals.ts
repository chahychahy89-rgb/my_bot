import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, referralsTable } from "@workspace/db";
import { eq, desc, sql, count } from "drizzle-orm";
import { getBotUsername } from "../lib/botInfo";

const router = Router();

export const INVITER_REWARD = 1000;
export const WELCOME_REWARD = 500;

const REFERRAL_MILESTONES = [
  { count: 1,  reward: 1000, rewardType: "coins",   label: "First Recruit" },
  { count: 3,  reward: 2,    rewardType: "diamonds", label: "Mining Squad" },
  { count: 5,  reward: 1,    rewardType: "diamonds", label: "Golden Key" },
  { count: 10, reward: 5,    rewardType: "diamonds", label: "Empire Builder" },
  { count: 25, reward: 15,   rewardType: "diamonds", label: "Mining Legend" },
];

// GET /referrals/leaderboard — top 10 users by referral count
router.get("/leaderboard", async (_req, res) => {
  const rows = await db
    .select({
      telegramId: referralsTable.referrerTelegramId,
      referralCount: count(referralsTable.id).as("referral_count"),
    })
    .from(referralsTable)
    .groupBy(referralsTable.referrerTelegramId)
    .orderBy(desc(sql`count(${referralsTable.id})`))
    .limit(10);

  const result = await Promise.all(
    rows.map(async (row, i) => {
      const user = await db.query.usersTable.findFirst({
        where: eq(usersTable.telegramId, row.telegramId),
      });
      return {
        rank: i + 1,
        telegramId: row.telegramId,
        firstName: user?.firstName ?? "Miner",
        username: user?.username ?? "user",
        level: user?.level ?? 1,
        referralCount: Number(row.referralCount),
        referralEarnings: parseFloat(user?.referralEarnings ?? "0"),
      };
    })
  );

  res.json(result);
});

// GET /referrals/:telegramId — user referral info
router.get("/:telegramId", async (req, res) => {
  const { telegramId } = req.params;

  const user = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const referrals = await db.query.referralsTable.findMany({
    where: eq(referralsTable.referrerTelegramId, telegramId),
  });

  const totalReferrals = referrals.length;
  const botUsername = getBotUsername();
  const referralLink = `https://t.me/${botUsername}?start=${user.referralCode}`;

  const shareMessage =
    `⛏ انضم إلى بوت التعدين وابدأ تجميع العملات مجاناً!\n\n` +
    `🎁 ستحصل على 500 عملة هدية ترحيبية فور انضمامك!\n` +
    `💰 اكسب عملات تلقائياً 24/7 بدون أي جهد\n` +
    `🏆 تنافس مع آلاف اللاعبين في لوحة الصدارة\n\n` +
    `👇 انضم الآن عبر رابطي الخاص:\n${referralLink}`;

  const milestones = REFERRAL_MILESTONES.map((m) => ({
    ...m,
    isAchieved: totalReferrals >= m.count,
  }));

  const friends = referrals.map((r) => ({
    username: r.refereeUsername,
    firstName: r.refereeFirstName,
    joinedAt: r.createdAt.toISOString(),
    reward: parseFloat(r.rewardAmount),
  }));

  res.json({
    referralCode: user.referralCode,
    referralLink,
    shareMessage,
    totalReferrals,
    referralEarnings: parseFloat(user.referralEarnings),
    inviterReward: INVITER_REWARD,
    welcomeReward: WELCOME_REWARD,
    friends,
    milestones,
  });
});

// POST /referrals/:telegramId/register — register a referral
router.post("/:telegramId/register", async (req, res) => {
  const { telegramId } = req.params;
  const { newUserTelegramId, newUserUsername, newUserFirstName } = req.body;

  const referrer = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, telegramId),
  });

  if (!referrer) {
    res.status(404).json({ success: false, reward: 0, message: "Referrer not found" });
    return;
  }

  const existing = await db.query.referralsTable.findFirst({
    where: eq(referralsTable.refereeTelegramId, newUserTelegramId),
  });

  if (existing) {
    res.json({ success: false, reward: 0, message: "User already referred" });
    return;
  }

  // Save referral record
  await db.insert(referralsTable).values({
    referrerTelegramId: telegramId,
    refereeTelegramId: newUserTelegramId,
    refereeUsername: newUserUsername,
    refereeFirstName: newUserFirstName,
    rewardAmount: INVITER_REWARD.toString(),
  });

  // Give 1000 coins to inviter
  const currentTotal = parseFloat(referrer.totalCoins);
  const currentEarnings = parseFloat(referrer.referralEarnings);
  await db.update(usersTable)
    .set({
      totalCoins: (currentTotal + INVITER_REWARD).toString(),
      referralEarnings: (currentEarnings + INVITER_REWARD).toString(),
    })
    .where(eq(usersTable.telegramId, telegramId));

  // Give 500 welcome coins to new user
  const newUser = await db.query.usersTable.findFirst({
    where: eq(usersTable.telegramId, newUserTelegramId),
  });
  if (newUser) {
    await db.update(usersTable)
      .set({ totalCoins: (parseFloat(newUser.totalCoins) + WELCOME_REWARD).toString() })
      .where(eq(usersTable.telegramId, newUserTelegramId));
  }

  res.json({
    success: true,
    inviterReward: INVITER_REWARD,
    welcomeReward: WELCOME_REWARD,
    message: `You earned ${INVITER_REWARD} coins for the referral!`,
  });
});

export default router;
