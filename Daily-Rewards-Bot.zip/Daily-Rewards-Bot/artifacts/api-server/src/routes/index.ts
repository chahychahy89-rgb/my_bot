import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import miningRouter from "./mining";
import tasksRouter from "./tasks";
import referralsRouter from "./referrals";
import leaderboardRouter from "./leaderboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/users", usersRouter);
router.use("/mining", miningRouter);
router.use("/tasks", tasksRouter);
router.use("/referrals", referralsRouter);
router.use("/leaderboard", leaderboardRouter);

export default router;
