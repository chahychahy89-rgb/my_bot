import { pgTable, serial, text, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const referralsTable = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerTelegramId: text("referrer_telegram_id").notNull(),
  refereeTelegramId: text("referee_telegram_id").notNull().unique(),
  refereeUsername: text("referee_username").notNull().default("user"),
  refereeFirstName: text("referee_first_name").notNull().default("User"),
  rewardAmount: numeric("reward_amount", { precision: 10, scale: 2 }).notNull().default("500"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertReferralSchema = createInsertSchema(referralsTable).omit({ id: true, createdAt: true });
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Referral = typeof referralsTable.$inferSelect;
