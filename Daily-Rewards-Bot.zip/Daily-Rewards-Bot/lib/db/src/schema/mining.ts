import { pgTable, serial, text, boolean, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const miningSessionsTable = pgTable("mining_sessions", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull(),
  isActive: boolean("is_active").notNull().default(false),
  startedAt: timestamp("started_at"),
  boostedUntil: timestamp("boosted_until"),
  baseCoinsPerHour: numeric("base_coins_per_hour", { precision: 10, scale: 4 }).notNull().default("100"),
  pendingCoins: numeric("pending_coins", { precision: 18, scale: 4 }).notNull().default("0"),
  lastUpdatedAt: timestamp("last_updated_at").notNull().defaultNow(),
  sessionDurationHours: integer("session_duration_hours").notNull().default(8),
});

export const insertMiningSessionSchema = createInsertSchema(miningSessionsTable).omit({ id: true });
export type InsertMiningSession = z.infer<typeof insertMiningSessionSchema>;
export type MiningSession = typeof miningSessionsTable.$inferSelect;
