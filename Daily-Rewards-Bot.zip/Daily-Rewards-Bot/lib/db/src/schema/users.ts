import { pgTable, text, serial, numeric, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username").notNull().default("user"),
  firstName: text("first_name").notNull().default("User"),
  totalCoins: numeric("total_coins", { precision: 18, scale: 4 }).notNull().default("0"),
  diamonds: numeric("diamonds", { precision: 10, scale: 2 }).notNull().default("0"),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: text("referred_by"),
  level: integer("level").notNull().default(1),
  referralEarnings: numeric("referral_earnings", { precision: 18, scale: 4 }).notNull().default("0"),
  dailyAdCount: integer("daily_ad_count").notNull().default(0),
  lastAdDate: text("last_ad_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
