import { pgTable, serial, text, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const taskDefinitionsTable = pgTable("task_definitions", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  reward: numeric("reward", { precision: 10, scale: 2 }).notNull(),
  rewardType: text("reward_type").notNull().default("coins"),
  taskType: text("task_type").notNull(),
  icon: text("icon").notNull().default("Star"),
  link: text("link"),
  isDaily: boolean("is_daily").notNull().default(true),
});

export const userTaskCompletionsTable = pgTable("user_task_completions", {
  id: serial("id").primaryKey(),
  telegramId: text("telegram_id").notNull(),
  taskId: text("task_id").notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
});

export const insertTaskDefinitionSchema = createInsertSchema(taskDefinitionsTable);
export type InsertTaskDefinition = z.infer<typeof insertTaskDefinitionSchema>;
export type TaskDefinition = typeof taskDefinitionsTable.$inferSelect;

export const insertUserTaskCompletionSchema = createInsertSchema(userTaskCompletionsTable).omit({ id: true });
export type InsertUserTaskCompletion = z.infer<typeof insertUserTaskCompletionSchema>;
export type UserTaskCompletion = typeof userTaskCompletionsTable.$inferSelect;
